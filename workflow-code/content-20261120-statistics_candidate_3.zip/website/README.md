# 展示代码与测试

在 website 目录运行 `node test_presentation_fields.js`。

在解压根目录运行 `python3 rsi_harness/workflow_verify_v3.py` 验证工作流。
