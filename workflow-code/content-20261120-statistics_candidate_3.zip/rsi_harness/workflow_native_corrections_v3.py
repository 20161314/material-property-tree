#!/usr/bin/env python3
"""Exact, withdrawal-only corrections against a complete pinned native snapshot.

prepare is read-only; apply requires a separately supplied, hash-pinned approval.
This adapter neither invokes models nor publishes nor changes an active pointer.
"""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

try:
    from .workflow_publication_v3 import contained, require, sha, verify_manifest
except ImportError:  # Direct CLI invocation.
    from workflow_publication_v3 import contained, require, sha, verify_manifest

SCHEMA = 'rsi-native-data-correction-v1'
FIELDS = frozenset({'review_status', 'independent_review_status', 'canonical_mapping_status'})
ROOT_DATA = frozenset({'snapshot.json', 'research.json', 'coverage.json', 'release-manifest.json', 'release-status.json'})


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def dump(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode() + b'\n'


def pinned(path, expected, label):
    require(isinstance(expected, str) and re.fullmatch('[0-9a-f]{64}', expected), 'Missing exact ' + label + ' SHA')
    require(sha(path) == expected, label + ' SHA mismatch')
    return load(path)


def public_projection(site, objects):
    """Run the actual pinned public consumer, not a second approval implementation."""
    script = contained(site, 'presentation-fields.js')
    code = "const p=require(process.argv[1]);let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>{console.log(JSON.stringify(JSON.parse(s).map(o=>({object_id:o.id,projection:(()=>{const q=p.objectPresentation(o);return {materials:q.materials,relation_ids:q.relations.map(r=>r.relation_id),components:q.components.map(c=>({component_id:c.row?.component_id||c.id||c.component_id||c.component?.component_id,name:c.name,relation_ids:c.relations.map(r=>r.relation_id)}))}})()}))))});"
    run = subprocess.run(['node', '-e', code, str(script)], input=json.dumps(objects), text=True,
                         capture_output=True, timeout=60)
    require(run.returncode == 0, 'Pinned public projection failed: ' + run.stderr[-500:])
    return json.loads(run.stdout)


def _approved(approval_path, approval_sha256, proposal_sha256, parent_sha256, project_root):
    require(approval_path is not None, 'Independent proposal approval required')
    approval = pinned(approval_path, approval_sha256, 'approval')
    require(approval.get('status') == 'APPROVE_CORRECTION_PROPOSAL', 'Unapproved correction proposal')
    require(approval.get('proposal_sha256') == proposal_sha256, 'Approval binds another proposal')
    require(approval.get('parent_manifest_sha256') == parent_sha256, 'Approval binds another parent')
    require(approval.get('independent') is True and approval.get('review_scope') == 'EXACT_NATIVE_RELATION_WITHDRAWAL', 'Independent exact withdrawal review required')
    require(approval.get('reviewer') and approval.get('author') and approval['reviewer'] != approval['author'], 'Self approval forbidden')
    require(approval.get('actual_agent_id') and approval.get('host_call_id'), 'Actual independent review receipt required')
    receipt_path = contained(project_root, approval.get('review_receipt_path', ''))
    receipt = pinned(receipt_path, approval.get('review_receipt_sha256'), 'review receipt')
    require(receipt.get('host_call_id') == approval['host_call_id'], 'Independent host call receipt mismatch')
    require(receipt.get('decision') == 'APPROVE_CORRECTION_PROPOSAL', 'Receipt does not approve correction actions')
    require(receipt.get('proposal_sha256') == proposal_sha256 and receipt.get('parent_manifest_sha256') == parent_sha256, 'Receipt binds different correction inputs')
    require(receipt.get('reviewer') == approval['reviewer'] == approval['actual_agent_id'], 'Independent reviewer identity mismatch')
    return approval


def prepare(source_site, proposal_path, *, parent_manifest_sha256, proposal_sha256, project_root,
            approval_path=None, approval_sha256=None):
    """Verify the entire parent and all preimages; never writes the source or a candidate."""
    source, project = Path(source_site).resolve(), Path(project_root).resolve()
    manifest = pinned(source / 'MANIFEST.json', parent_manifest_sha256, 'parent manifest')
    require(verify_manifest(source) == manifest, 'Parent changed during verification')
    require({'snapshot.json', 'research.json', 'coverage.json', 'bootstrap.js', 'presentation-fields.js'} <= manifest['files'].keys(), 'Not a full native snapshot')
    proposal = pinned(proposal_path, proposal_sha256, 'proposal')
    require(proposal.get('schema') == 'rsi-native-correction-proposal-v1', 'Unknown proposal schema')
    require(proposal.get('parent_snapshot_id') == manifest.get('snapshot_id'), 'Wrong parent snapshot')
    require(proposal.get('requires_full_parent_native_data_run') is True, 'Full native data run required')
    require(proposal.get('numeric_values_changed') == 0 and proposal.get('new_material_labels_invented') == 0, 'Proposal exceeds withdrawal-only scope')
    if approval_path is not None:
        _approved(approval_path, approval_sha256, proposal_sha256, parent_manifest_sha256, project_root)
    adjudication = contained(project, proposal['adjudication'])
    adjudicated = pinned(adjudication, proposal['adjudication_sha256'], 'adjudication')
    decisions = {r['record_id']: r for r in adjudicated.get('decisions', [])}
    materials = {r['id'] for r in load(source / 'research.json').get('nodes', [])}
    operations = proposal.get('operations')
    require(isinstance(operations, list) and operations, 'No correction operations')
    documents, seen, records, identities, before_objects = {}, set(), set(), set(), {}
    edits = []
    for op in operations:
        require(op.get('record_id') and op['record_id'] not in records, 'Duplicate record operation')
        records.add(op['record_id'])
        decision = op.get('effective_decision')
        require(decision in ('HOLD', 'REJECT'), 'Only HOLD/REJECT withdrawals allowed')
        rid = op.get('scope_to_correct', {}).get('exact_relation_id')
        require(rid and op['scope_to_correct'].get('exact_record_id') == op['record_id'], 'Unbound relation identity')
        identity = (op.get('object_id'), op.get('component_id'), op.get('material_id'), rid)
        require(all(identity) and identity not in identities, 'Duplicate or incomplete relation identity')
        identities.add(identity)
        require(op['material_id'] in materials, 'Material ID absent from native material tree')
        reviewed = decisions.get(op['record_id'], {})
        require(all(reviewed.get(k) == op.get(k) for k in ('object_id', 'component_id', 'material_id', 'effective_decision'))
                and reviewed.get('relation_id') == rid, 'Operation differs from pinned semantic adjudication')
        frozen_file = contained(project, op['source_file'])
        pinned_bytes = frozen_file.read_bytes()
        require(hashlib.sha256(pinned_bytes).hexdigest() == op['source_file_sha256'], 'Frozen input SHA mismatch')
        row_ops = op.get('row_operations', [])
        require(len(row_ops) == 2 and {r.get('source_stream') for r in row_ops} == {'source', 'links'}, 'Both source/link mirrors required')
        targeted, locations = set(), set()
        for row_op in row_ops:
            locator = row_op.get('input_locator', '')
            match = re.fullmatch(r'private-inputs/(objects/[0-9]+\.json\.gz)#/([0-9]+)/relations/([0-9]+)', locator)
            require(match is not None, 'Unsafe or unsupported input locator')
            name, oi, ri = match.group(1), int(match.group(2)), int(match.group(3))
            locations.add((name, oi))
            require(len(locations) == 1, 'Mirrors belong to different object rows')
            require(('/' + op['source_file']).endswith('/private-inputs/' + name), 'Locator does not bind frozen source file')
            require(name in manifest['files'] and manifest['files'][name] == op['source_file_sha256'], 'Frozen/native bytes differ')
            require(contained(source, name).read_bytes() == pinned_bytes, 'Frozen/native bytes differ')
            if name not in documents:
                documents[name] = json.loads(gzip.decompress(pinned_bytes))
            objects = documents[name]
            require(isinstance(objects, list) and oi < len(objects), 'Object index missing')
            obj = objects[oi]
            require(obj.get('id') == op['object_id'], 'Wrong object ID')
            require(any(c.get('component_id') == op['component_id'] and c.get('material_node_id') == op['material_id'] for c in obj.get('components', [])), 'Wrong component/material ID')
            require(ri < len(obj.get('relations', [])), 'Relation index missing')
            row = obj['relations'][ri]
            require(row.get('object_id') == op['object_id'] and row.get('component_id') == op['component_id'], 'Wrong row object/component ID')
            require(row.get('relation_id') == rid == row_op.get('source_relation_id') and row.get('stream') == row_op.get('source_stream'), 'Wrong relation ID/stream')
            if row['stream'] == 'links':
                require(row.get('target_material_id') == op['material_id'], 'Wrong link material ID')
            require(digest(row) == row_op.get('before_sha256'), 'Row preimage mismatch')
            key = (name, oi, ri)
            require(key not in seen, 'Duplicate row operation')
            seen.add(key)
            targeted.add(ri)
            fields = row_op.get('set_fields', {})
            require(set(fields) <= FIELDS and {'review_status', 'independent_review_status'} <= fields.keys(), 'Non-whitelisted field or incomplete withdrawal')
            require(row['stream'] != 'source' or 'canonical_mapping_status' in fields, 'Source canonical mirror can revive relation')
            require(all(isinstance(v, str) and re.fullmatch(decision + r'(?:_[A-Z0-9]+)*', v) for v in fields.values()), 'Non-withdrawal status')
            before_objects[(name, oi)] = obj
            edits.append(dict(file=name, object_index=oi, relation_index=ri, fields=fields))
        matches = {i for i, row in enumerate(obj['relations']) if row.get('relation_id') == rid and row.get('component_id') == op['component_id']}
        require(matches == targeted, 'Uncovered relation mirror')
    require(len(seen) == proposal.get('source_rows') and len(identities) == proposal.get('affected_public_relations'), 'Proposal row/relation totals mismatch')
    target_objects = {o for o, _, _, _ in identities}
    target_relations = {r for _, _, _, r in identities}
    object_locations, relation_locations = {}, set()
    for name in manifest['files']:
        if not re.fullmatch(r'objects/[0-9]+\.json\.gz', name):
            continue
        objects = documents.get(name)
        if objects is None:
            objects = json.loads(gzip.decompress((source / name).read_bytes()))
        for oi, obj in enumerate(objects):
            if obj.get('id') in target_objects:
                require(obj['id'] not in object_locations, 'Target object repeated in native snapshot')
                object_locations[obj['id']] = (name, oi)
            for ri, row in enumerate(obj.get('relations', [])):
                if row.get('relation_id') in target_relations:
                    relation_locations.add((name, oi, ri))
    require(relation_locations == seen and set(object_locations) == target_objects, 'Uncovered relation mirror in complete native snapshot')
    changed = copy.deepcopy(documents)
    for edit in edits:
        changed[edit['file']][edit['object_index']]['relations'][edit['relation_index']].update(edit['fields'])
    ordered = sorted(before_objects)
    before = public_projection(source, [documents[n][i] for n, i in ordered])
    after = public_projection(source, [changed[n][i] for n, i in ordered])
    # Count exact approved link rows through the same pinned public admission function.
    code = "const p=require(process.argv[1]);let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>console.log(JSON.stringify(JSON.parse(s).map(o=>p.objectPresentation(o).relations.map(r=>[o.id,r.relation_id,r.component_id,r.materialId||r.target_material_id||r.canonical_material_id||''])))))"
    def admitted(docs):
        run = subprocess.run(['node', '-e', code, str(source / 'presentation-fields.js')], input=json.dumps([docs[n][i] for n, i in ordered]), text=True, capture_output=True, timeout=60)
        require(run.returncode == 0, 'Public admission failed')
        return {tuple(r) for group in json.loads(run.stdout) for r in group}
    old, new = admitted(documents), admitted(changed)
    expected = {(o, r, c, m) for o, c, m, r in identities}
    require(old - new == expected and not new - old, 'Public withdrawal is not the exact approved relation set')
    child = 'RSI-CORRECTED-' + hashlib.sha256((parent_manifest_sha256 + proposal_sha256).encode()).hexdigest()[:16]
    reconciliation = dict(proposed_public_relation_withdrawals=len(identities),
                          approved_public_relation_withdrawals=len(identities) if approval_path is not None else 0, modified_source_link_rows=len(seen),
                          new_objects=0, new_components=0, numerical_values_changed=0,
                          source_association_statistics='PRESERVED_PARENT_DEFINITION_NOT_ACCEPTED_RELATION_COUNTS',
                          global_geometry_deduplication_performed=False, original_papers_individually_rechecked=False, global_four_state_recalculation_performed=False,
                          public_projection_before=before, public_projection_after=after,
                          withdrawn_relation_keys=sorted([list(k) for k in old - new]))
    return dict(schema=SCHEMA, status='PREPARED_NOT_APPLIED', source_site=str(source),
                parent_manifest_sha256=parent_manifest_sha256, proposal_sha256=proposal_sha256,
                parent_snapshot_id=manifest['snapshot_id'], snapshot_id=child, edits=edits,
                source_manifest_files=len(manifest['files']), proposal_independently_approved=approval_path is not None,
                reconciliation=reconciliation)


def _metadata(value, old, new, hashes=None):
    """Only current entry metadata and current url+sha references; history stays untouched."""
    value = copy.deepcopy(value)
    for key in ('releaseId', 'snapshot_id', 'release_id'):
        if value.get(key) == old:
            value[key] = new
    if isinstance(value.get('meta'), dict) and value['meta'].get('releaseId') == old:
        value['meta']['releaseId'] = new
    if hashes is not None:
        if value.get('id') == old:
            value['id'] = new
        def refs(v):
            if isinstance(v, dict):
                if v.get('url') in hashes and 'sha256' in v:
                    v['sha256'] = hashes[v['url']]
                for k, item in v.items():
                    if k not in ('display_derivation', 'layout_derivation', 'working_projection', 'tree_scope', 'parent', 'history'):
                        refs(item)
            elif isinstance(v, list):
                for item in v:
                    refs(item)
        refs(value)
    return value


def _outputs(source, plan):
    """Yield deterministic expected bytes, retaining every unmodified parent file."""
    manifest = pinned(source / 'MANIFEST.json', plan['parent_manifest_sha256'], 'parent manifest')
    edits = {}
    for edit in plan['edits']:
        edits.setdefault(edit['file'], []).append(edit)
    runtime_hashes = {}
    bootstrap_sha256 = None
    old, new = plan['parent_snapshot_id'], plan['snapshot_id']
    deferred = ROOT_DATA | {'release-data.js'} | {n for n in manifest['files'] if n.endswith('.html')}
    for name in manifest['files']:
        if name in deferred:
            continue
        raw = contained(source, name).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == manifest['files'][name], 'Parent file changed during transformation: ' + name)
        if name.endswith('.json.gz'):
            payload = gzip.decompress(raw)
            value = json.loads(payload)
            changed = False
            if name in edits:
                for edit in edits[name]:
                    value[edit['object_index']]['relations'][edit['relation_index']].update(edit['fields'])
                changed = True
            if isinstance(value, dict):
                updated = _metadata(value, old, new)
                changed |= updated != value
                value = updated
            if changed:
                payload = canonical(value)
                raw = gzip.compress(payload, mtime=0)
            runtime_hashes[name] = hashlib.sha256(payload).hexdigest()
        elif name == 'bootstrap.js':
            require(raw.count(old.encode()) == 1, 'Unexpected bootstrap release binding')
            raw = raw.replace(old.encode(), new.encode())
        if name == 'bootstrap.js':
            bootstrap_sha256 = hashlib.sha256(raw).hexdigest()
        yield name, raw
    for name in sorted(deferred & manifest['files'].keys()):
        raw = contained(source, name).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == manifest['files'][name], 'Parent file changed during transformation: ' + name)
        if name.endswith('.html'):
            if name in ('mapping-archive.html', 'phase1-ranges.html'):
                raw = raw.replace(('snapshot=' + old).encode(), ('snapshot=' + new).encode())
            require(bootstrap_sha256 is not None, 'Missing new bootstrap cache binding')
            text = raw.decode('utf-8')
            text = re.sub(r'''(\bsrc\s*=\s*['"]bootstrap\.js)(?:\?[^'"<>]*)?(['"])''',
                          lambda m: m.group(1) + '?v=' + bootstrap_sha256 + m.group(2), text)
            raw = text.encode('utf-8')
        elif name == 'release-data.js':
            prefix = b'window.DATASET_RELEASE='
            require(raw.startswith(prefix) and raw.rstrip().endswith(b';'), 'Unsupported release-data.js wrapper')
            value = json.loads(raw[len(prefix):].strip()[:-1])
            raw = prefix + canonical(_metadata(value, old, new, runtime_hashes)) + b';\n'
        else:
            raw = dump(_metadata(json.loads(raw), old, new, runtime_hashes))
        yield name, raw


def verify(candidate, source_site, proposal_path, *, parent_manifest_sha256, proposal_sha256,
           project_root, approval_path, approval_sha256):
    _approved(approval_path, approval_sha256, proposal_sha256, parent_manifest_sha256, project_root)
    plan = prepare(source_site, proposal_path, parent_manifest_sha256=parent_manifest_sha256,
                   proposal_sha256=proposal_sha256, project_root=project_root,
                   approval_path=approval_path, approval_sha256=approval_sha256)
    candidate, source = Path(candidate).resolve(), Path(source_site).resolve()
    manifest = verify_manifest(candidate)
    require(manifest.get('snapshot_id') == plan['snapshot_id'], 'Wrong child ID')
    require('workflow_parent' not in manifest, 'Data correction cannot use presentation-only parent contract')
    contract = manifest.get('data_correction_contract', {})
    expected_contract = dict(schema=SCHEMA, parent=dict(source_site=str(source), manifest_sha256=parent_manifest_sha256,
                             snapshot_id=plan['parent_snapshot_id']), proposal_sha256=proposal_sha256,
                             proposal_path=str(Path(proposal_path).resolve()), approval_sha256=approval_sha256, approval_path=str(Path(approval_path).resolve()),
                             adapter_sha256=sha(__file__), reconciliation=plan['reconciliation'])
    require(contract == expected_contract, 'Data correction contract mismatch')
    require(manifest.get('native_correction_digest') == digest(contract), 'Native correction digest mismatch')
    expected_metadata = copy.deepcopy(load(source / 'MANIFEST.json'))
    expected_metadata.pop('workflow_parent', None)
    expected_metadata.pop('workflow_presentation_overrides', None)
    expected_metadata.pop('inherited_native_correction', None)
    expected_metadata.update(snapshot_id=plan['snapshot_id'], publication_authorized=False, production_write=False,
                             data_correction_contract=expected_contract, native_correction_digest=digest(expected_contract))
    require({k: v for k, v in manifest.items() if k != 'files'} ==
            {k: v for k, v in expected_metadata.items() if k != 'files'}, 'Unexpected manifest metadata mutation')
    require(manifest.get('publication_authorized') is False and manifest.get('production_write') is False, 'Adapter cannot authorize publication')
    expected_files = {}
    for name, raw in _outputs(source, plan):
        expected_files[name] = hashlib.sha256(raw).hexdigest()
    require(manifest['files'] == expected_files, 'Candidate differs from exact approved transformation')
    actual = {str(p.relative_to(candidate)) for p in candidate.rglob('*') if p.is_file()}
    require(actual == set(expected_files) | {'MANIFEST.json'}, 'Unpinned candidate file')
    require(load(candidate / 'snapshot.json')['id'] == plan['snapshot_id'], 'Snapshot child binding missing')
    pinned(source / 'MANIFEST.json', parent_manifest_sha256, 'parent manifest')
    verify_manifest(source)
    return dict(schema=SCHEMA, status='PASS_NATIVE_CORRECTION', snapshot_id=plan['snapshot_id'],
                manifest_sha256=sha(candidate / 'MANIFEST.json'), file_count=len(expected_files),
                reconciliation=plan['reconciliation'], publication_authorized=False)


def apply(source_site, proposal_path, out_site, *, parent_manifest_sha256, proposal_sha256,
          project_root, approval_path, approval_sha256):
    args = dict(parent_manifest_sha256=parent_manifest_sha256, proposal_sha256=proposal_sha256,
                project_root=project_root, approval_path=approval_path, approval_sha256=approval_sha256)
    # Always reverify independent authorization, including an idempotent retry.
    _approved(approval_path, approval_sha256, proposal_sha256, parent_manifest_sha256, project_root)
    plan = prepare(source_site, proposal_path, **args)
    source, output = Path(source_site).resolve(), Path(out_site).absolute()
    require(not output.is_symlink() and not output.resolve().is_relative_to(source), 'Unsafe candidate destination')
    if output.exists():
        return verify(output, source_site, proposal_path, **args)
    output.parent.mkdir(parents=True, exist_ok=True)
    require(not any(p.is_symlink() for p in [output.parent, *output.parent.parents]), 'Symlink destination')
    staging = Path(tempfile.mkdtemp(prefix='.' + output.name + '-', dir=output.parent))
    try:
        manifest = copy.deepcopy(load(source / 'MANIFEST.json'))
        manifest.pop('workflow_parent', None)
        manifest.pop('workflow_presentation_overrides', None)
        manifest.pop('inherited_native_correction', None)
        manifest.update(snapshot_id=plan['snapshot_id'], publication_authorized=False, production_write=False)
        manifest['data_correction_contract'] = dict(schema=SCHEMA, parent=dict(source_site=str(source),
            manifest_sha256=parent_manifest_sha256, snapshot_id=plan['parent_snapshot_id']),
            proposal_sha256=proposal_sha256, proposal_path=str(Path(proposal_path).resolve()), approval_sha256=approval_sha256,
            approval_path=str(Path(approval_path).resolve()), adapter_sha256=sha(__file__),
            reconciliation=plan['reconciliation'])
        manifest['native_correction_digest'] = digest(manifest['data_correction_contract'])
        manifest['files'] = {}
        for name, raw in _outputs(source, plan):
            path = contained(staging, name)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            manifest['files'][name] = hashlib.sha256(raw).hexdigest()
        (staging / 'MANIFEST.json').write_bytes(dump(manifest))
        result = verify(staging, source_site, proposal_path, **args)
        require(not output.exists(), 'Candidate target appeared during build')
        os.rename(staging, output)
        return result
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('prepare', 'verify', 'apply'))
    parser.add_argument('--source-site', required=True)
    parser.add_argument('--proposal', required=True)
    parser.add_argument('--parent-manifest-sha256', required=True)
    parser.add_argument('--proposal-sha256', required=True)
    parser.add_argument('--project-root', required=True)
    parser.add_argument('--approval')
    parser.add_argument('--approval-sha256')
    parser.add_argument('--out-site')
    args = parser.parse_args()
    kwargs = dict(parent_manifest_sha256=args.parent_manifest_sha256, proposal_sha256=args.proposal_sha256,
                  project_root=args.project_root, approval_path=args.approval, approval_sha256=args.approval_sha256)
    if args.command == 'prepare':
        result = prepare(args.source_site, args.proposal, **kwargs)
    else:
        require(args.out_site is not None, '--out-site required')
        method = apply if args.command == 'apply' else verify
        if args.command == 'apply':
            result = method(args.source_site, args.proposal, args.out_site, **kwargs)
        else:
            result = method(args.out_site, args.source_site, args.proposal, **kwargs)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
