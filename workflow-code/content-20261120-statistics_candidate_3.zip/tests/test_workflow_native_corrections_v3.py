"""Withdrawal adapter: full parent, exact preimages, independent approval, immutable child."""
import copy
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from rsi_harness import workflow_native_corrections_v3 as native


class NativeCorrectionTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.site = self.root / 'parent'
        self.site.mkdir()
        self.proposal_path = self.root / 'proposal.json'
        self.approval_path = self.root / 'independent-approval.json'
        self.candidate = self.root / 'child'
        row = dict(relation_id='R1', object_id='O1', component_id='C1', source_quote='Keep author text',
                   review_status='PASS', canonical_mapping_status='PASS', stream='source')
        link = dict(row, stream='links', target_material_id='M1', independent_review_status='PASS')
        self.obj = dict(id='O1', components=[dict(component_id='C1', material_node_id='M1')], relations=[row, link])
        data = gzip.compress(native.canonical([self.obj]), mtime=0)
        self.put('objects/0000.json.gz', data)
        self.put('coverage-details/000.json.gz', gzip.compress(native.canonical(dict(releaseId='PARENT', values={'E': 10, 'nu': 0.3, 'rho': 1000})), mtime=0))
        self.put('object-cards/0000.json.gz', gzip.compress(native.canonical([dict(id='O1', materials=['M1'])]), mtime=0))
        frozen = self.root / 'private-inputs/objects/0000.json.gz'
        frozen.parent.mkdir(parents=True)
        frozen.write_bytes(data)
        ref = dict(url='objects/0000.json.gz', sha256=hashlib.sha256(gzip.decompress(data)).hexdigest(), records=1)
        snapshot = dict(id='PARENT', snapshot_id='PARENT', release_id='PARENT', kind='REVIEWED_RESEARCH_SNAPSHOT', object_pages=[ref], completion_flags={'global_geometry_deduplicated': False},
                        history=dict(releaseId='PARENT', snapshot_id='PARENT', release_id='PARENT', old_value=42))
        for name, value in [('snapshot.json', snapshot), ('release-manifest.json', snapshot),
                            ('release-status.json', dict(id='PARENT')), ('research.json', dict(meta=dict(releaseId='PARENT'), nodes=[dict(id='M1')])),
                            ('coverage.json', dict(releaseId='PARENT'))]:
            self.put(name, native.dump(value))
        self.put('release-data.js', b'window.DATASET_RELEASE=' + native.canonical(snapshot) + b';\n')
        self.put('bootstrap.js', b"const version='PARENT';fetch('snapshot.json');")
        self.put('mapping-archive.html', b'<a href="scaling.html?snapshot=PARENT">Open</a>')
        self.put('snapshot.js', native.canonical(['scaling.html', 'research.html', 'references.html', 'workflow.html']))
        for page in ('scaling.html', 'research.html', 'references.html', 'workflow.html'):
            self.put(page, b'<script src="bootstrap.js?v=old-bootstrap-hash"></script><script src="snapshot.js"></script>')
        self.put('INPUT_PINS.json', native.dump(dict(historical_release='PARENT', historical_sha256='abc')))
        self.put('presentation-fields.js', b"""
function accepted(r){return r.stream==='links'&&!/HOLD|REJECT/.test(r.review_status+' '+r.independent_review_status)}
function objectPresentation(o){let r=o.relations.filter(accepted).map(r=>({...r,materialId:r.target_material_id}));return {relations:r,materials:r.map(r=>[r.target_material_id,'Material']),components:o.components.map(c=>({id:c.component_id,name:'Whole',relations:r.filter(r=>r.component_id===c.component_id)}))}}
module.exports={accepted,objectPresentation};
""")
        self.repin()
        (self.root / 'adjudication.json').write_bytes(native.dump(dict(decisions=[dict(record_id='REC1', object_id='O1', component_id='C1', material_id='M1', relation_id='R1', effective_decision='REJECT')])))
        (self.root / 'review.json').write_bytes(native.dump(dict(host_call_id='host-call-1')))
        self.proposal = dict(schema='rsi-native-correction-proposal-v1', parent_snapshot_id='PARENT',
                             adjudication='adjudication.json', adjudication_sha256=native.sha(self.root / 'adjudication.json'),
                             affected_public_relations=1, source_rows=2, numeric_values_changed=0,
                             new_material_labels_invented=0, requires_full_parent_native_data_run=True,
                             operations=[dict(record_id='REC1', object_id='O1', component_id='C1', material_id='M1',
                                              effective_decision='REJECT', scope_to_correct=dict(exact_record_id='REC1', exact_relation_id='R1'),
                                              source_file='private-inputs/objects/0000.json.gz', source_file_sha256=native.sha(frozen),
                                              row_operations=[dict(input_locator=f'private-inputs/objects/0000.json.gz#/0/relations/{i}',
                                                                   before_sha256=native.digest(r), source_relation_id='R1', source_stream=r['stream'],
                                                                   set_fields=dict(review_status='REJECT_CONFLICT', independent_review_status='REJECT_CONFLICT',
                                                                                   **({'canonical_mapping_status':'REJECT_CONFLICT'} if i == 0 else {}))) for i, r in enumerate([row, link])])])
        self.bind()

    def put(self, name, raw):
        target = self.site / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)

    def repin(self):
        manifest = dict(snapshot_id='PARENT', publication_type='REVIEWED_RESEARCH_SNAPSHOT',
                        workflow_parent=dict(source_site='history', manifest_sha256='history'),
                        files={str(p.relative_to(self.site)): native.sha(p) for p in self.site.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'})
        (self.site / 'MANIFEST.json').write_bytes(native.dump(manifest))

    def bind(self):
        self.proposal_path.write_bytes(native.dump(self.proposal))
        self.kwargs = dict(parent_manifest_sha256=native.sha(self.site / 'MANIFEST.json'),
                           proposal_sha256=native.sha(self.proposal_path), project_root=self.root)
        (self.root / 'review.json').write_bytes(native.dump(dict(host_call_id='host-call-1', decision='APPROVE_CORRECTION_PROPOSAL', reviewer='agent-2', proposal_sha256=self.kwargs['proposal_sha256'], parent_manifest_sha256=self.kwargs['parent_manifest_sha256'])))
        approval = dict(status='APPROVE_CORRECTION_PROPOSAL', proposal_sha256=self.kwargs['proposal_sha256'],
                        parent_manifest_sha256=self.kwargs['parent_manifest_sha256'], reviewer='agent-2', author='author',
                        independent=True, review_scope='EXACT_NATIVE_RELATION_WITHDRAWAL', actual_agent_id='agent-2',
                        review_receipt_path='review.json', review_receipt_sha256=native.sha(self.root / 'review.json'), host_call_id='host-call-1')
        self.approval_path.write_bytes(native.dump(approval))
        self.authorized = dict(self.kwargs, approval_path=self.approval_path, approval_sha256=native.sha(self.approval_path))

    def test_full_child_and_idempotency_preserve_numbers_history_and_source_associations(self):
        before = native.sha(self.site / 'MANIFEST.json')
        result = native.apply(self.site, self.proposal_path, self.candidate, **self.authorized)
        self.assertEqual(result['status'], 'PASS_NATIVE_CORRECTION')
        self.assertEqual(result, native.apply(self.site, self.proposal_path, self.candidate, **self.authorized))
        self.assertEqual(before, native.sha(self.site / 'MANIFEST.json'))
        manifest = native.load(self.candidate / 'MANIFEST.json')
        self.assertNotIn('workflow_parent', manifest)
        self.assertEqual(set(manifest['files']), set(native.load(self.site / 'MANIFEST.json')['files']))
        snapshot = native.load(self.candidate / 'snapshot.json')
        self.assertNotEqual(snapshot['id'], 'PARENT')
        self.assertEqual(snapshot['history'], dict(releaseId='PARENT', snapshot_id='PARENT', release_id='PARENT', old_value=42))
        for name in ('snapshot.json', 'release-manifest.json'):
            aliases = native.load(self.candidate / name)
            self.assertEqual({aliases[k] for k in ('id', 'snapshot_id', 'release_id')}, {snapshot['id']})
        self.assertEqual(snapshot['completion_flags'], {'global_geometry_deduplicated': False})
        self.assertEqual(snapshot['object_pages'][0]['sha256'], hashlib.sha256(gzip.decompress((self.candidate / 'objects/0000.json.gz').read_bytes())).hexdigest())
        self.assertNotEqual(snapshot['object_pages'][0]['sha256'], native.sha(self.candidate / 'objects/0000.json.gz'))
        self.assertIn(('bootstrap.js?v=' + native.sha(self.candidate / 'bootstrap.js')).encode(), (self.candidate / 'scaling.html').read_bytes())
        self.assertIn(snapshot['id'].encode(), (self.candidate / 'mapping-archive.html').read_bytes())
        values = json.loads(gzip.decompress((self.candidate / 'coverage-details/000.json.gz').read_bytes()))
        self.assertEqual(values, dict(releaseId=snapshot['id'], values={'E': 10, 'nu': 0.3, 'rho': 1000}))
        self.assertEqual((self.site / 'object-cards/0000.json.gz').read_bytes(), (self.candidate / 'object-cards/0000.json.gz').read_bytes())
        self.assertEqual((self.site / 'INPUT_PINS.json').read_bytes(), (self.candidate / 'INPUT_PINS.json').read_bytes())
        obj = json.loads(gzip.decompress((self.candidate / 'objects/0000.json.gz').read_bytes()))[0]
        self.assertEqual(obj['components'], self.obj['components'])
        self.assertTrue(all(r['review_status'].startswith('REJECT') for r in obj['relations']))
        self.assertEqual(result['reconciliation']['approved_public_relation_withdrawals'], 1)
        self.assertEqual(result['reconciliation']['public_projection_after'][0]['projection']['materials'], [])

    def test_second_native_correction_after_real_presentation_wrapper(self):
        from rsi_harness import workflow_publication_v3 as publication
        obj2 = copy.deepcopy(self.obj)
        obj2['id'] = 'O2'
        obj2['components'][0]['component_id'] = 'C2'
        for row in obj2['relations']:
            row.update(object_id='O2', component_id='C2', relation_id='R2')
        data = gzip.compress(native.canonical([self.obj, obj2]), mtime=0)
        self.put('objects/0000.json.gz', data)
        frozen = self.root / 'private-inputs/objects/0000.json.gz'
        frozen.write_bytes(data)
        self.proposal['operations'][0]['source_file_sha256'] = native.sha(frozen)
        for name in ('snapshot.json', 'release-manifest.json'):
            value = native.load(self.site / name)
            value['object_pages'][0].update(sha256=hashlib.sha256(gzip.decompress(data)).hexdigest(), records=2)
            self.put(name, native.dump(value))
        self.repin()
        baseline = native.load(self.site / 'MANIFEST.json')
        baseline.pop('workflow_parent')
        (self.site / 'MANIFEST.json').write_bytes(native.dump(baseline))
        self.bind()
        first = native.apply(self.site, self.proposal_path, self.candidate, **self.authorized)
        wrapper = self.root / 'ui-wrapper'
        with patch.object(publication, 'PROJECT', self.root):
            built = publication.build_site(self.candidate, wrapper)
        self.assertEqual(built['status'], 'PASS_SITE_SNAPSHOT_STRUCTURE')
        self.assertEqual(built['effective_native_correction_digest'], native.load(self.candidate / 'MANIFEST.json')['native_correction_digest'])
        self.assertIn('inherited_native_correction', native.load(wrapper / 'MANIFEST.json'))
        rows = json.loads(gzip.decompress((wrapper / 'objects/0000.json.gz').read_bytes()))
        self.assertEqual(rows[1]['relations'][1]['review_status'], 'PASS')
        second_frozen = self.root / 'round2/private-inputs/objects/0000.json.gz'
        second_frozen.parent.mkdir(parents=True)
        second_frozen.write_bytes((wrapper / 'objects/0000.json.gz').read_bytes())
        adjudication2 = self.root / 'adjudication2.json'
        adjudication2.write_bytes(native.dump(dict(decisions=[dict(record_id='REC2', object_id='O2', component_id='C2', material_id='M1', relation_id='R2', effective_decision='HOLD')])))
        proposal2 = copy.deepcopy(self.proposal)
        proposal2.update(parent_snapshot_id=first['snapshot_id'], adjudication='adjudication2.json', adjudication_sha256=native.sha(adjudication2))
        op = proposal2['operations'][0]
        op.update(record_id='REC2', object_id='O2', component_id='C2', effective_decision='HOLD',
                  scope_to_correct=dict(exact_record_id='REC2', exact_relation_id='R2'),
                  source_file='round2/private-inputs/objects/0000.json.gz', source_file_sha256=native.sha(second_frozen))
        for index, row_op in enumerate(op['row_operations']):
            row_op.update(input_locator=f'private-inputs/objects/0000.json.gz#/1/relations/{index}',
                          before_sha256=native.digest(rows[1]['relations'][index]), source_relation_id='R2')
            row_op['set_fields'] = {key:'HOLD_CONFLICT' for key in row_op['set_fields']}
        proposal_path2 = self.root / 'proposal2.json'
        proposal_path2.write_bytes(native.dump(proposal2))
        kwargs2 = dict(project_root=self.root, parent_manifest_sha256=native.sha(wrapper / 'MANIFEST.json'), proposal_sha256=native.sha(proposal_path2))
        review2 = self.root / 'review2.json'
        review2.write_bytes(native.dump(dict(host_call_id='host-call-2', decision='APPROVE_CORRECTION_PROPOSAL', reviewer='agent-3',
                                           proposal_sha256=kwargs2['proposal_sha256'], parent_manifest_sha256=kwargs2['parent_manifest_sha256'])))
        approval2 = self.root / 'approval2.json'
        approval2.write_bytes(native.dump(dict(status='APPROVE_CORRECTION_PROPOSAL', proposal_sha256=kwargs2['proposal_sha256'],
                                              parent_manifest_sha256=kwargs2['parent_manifest_sha256'], reviewer='agent-3', author='author',
                                              independent=True, review_scope='EXACT_NATIVE_RELATION_WITHDRAWAL', actual_agent_id='agent-3',
                                              review_receipt_path='review2.json', review_receipt_sha256=native.sha(review2), host_call_id='host-call-2')))
        kwargs2.update(approval_path=approval2, approval_sha256=native.sha(approval2))
        second_child = self.root / 'second-child'
        second = native.apply(wrapper, proposal_path2, second_child, **kwargs2)
        manifest2 = native.load(second_child / 'MANIFEST.json')
        self.assertNotIn('inherited_native_correction', manifest2)
        self.assertNotIn('workflow_parent', manifest2)
        self.assertEqual(manifest2['data_correction_contract']['parent']['manifest_sha256'], native.sha(wrapper / 'MANIFEST.json'))
        with patch.object(publication, 'PROJECT', self.root):
            final = publication.validate_site(second_child)
        self.assertEqual(final['status'], 'PASS_SITE_SNAPSHOT_STRUCTURE')
        self.assertEqual(final['snapshot_id'], second['snapshot_id'])
        self.assertNotEqual(first['snapshot_id'], second['snapshot_id'])
        last_rows = json.loads(gzip.decompress((second_child / 'objects/0000.json.gz').read_bytes()))
        self.assertTrue(all(r['review_status'].startswith('REJECT') for r in last_rows[0]['relations']))
        self.assertTrue(all(r['review_status'].startswith('HOLD') for r in last_rows[1]['relations']))
        aliases = native.load(second_child / 'release-manifest.json')
        self.assertEqual({aliases[k] for k in ('id', 'snapshot_id', 'release_id')}, {second['snapshot_id']})
        self.assertEqual(aliases['history']['release_id'], 'PARENT')

    def test_wrong_sha_and_preimage_rejected(self):
        for field in ('parent_manifest_sha256', 'proposal_sha256'):
            with self.subTest(field=field), self.assertRaises(ValueError):
                native.prepare(self.site, self.proposal_path, **dict(self.kwargs, **{field:'0'*64}))
        self.proposal['operations'][0]['row_operations'][0]['before_sha256'] = '0'*64
        self.bind()
        with self.assertRaisesRegex(ValueError, 'preimage'):
            native.prepare(self.site, self.proposal_path, **self.kwargs)

    def test_unsafe_locator_and_input_path_rejected(self):
        original = copy.deepcopy(self.proposal)
        for locator in ('private-inputs/objects/../0000.json.gz#/0/relations/0', '/private-inputs/objects/0000.json.gz#/0/relations/0'):
            self.proposal = copy.deepcopy(original)
            self.proposal['operations'][0]['row_operations'][0]['input_locator'] = locator
            self.bind()
            with self.assertRaises(ValueError):
                native.prepare(self.site, self.proposal_path, **self.kwargs)
        self.proposal = copy.deepcopy(original)
        self.proposal['operations'][0]['source_file'] = '../outside.gz'
        self.bind()
        with self.assertRaisesRegex(ValueError, 'Path escape'):
            native.prepare(self.site, self.proposal_path, **self.kwargs)

    def test_missing_mirror_nonwhitelist_numeric_and_promotion_rejected(self):
        original = copy.deepcopy(self.proposal)
        mutations = [lambda p:p['operations'][0]['row_operations'].pop(),
                     lambda p:p['operations'][0]['row_operations'][0]['set_fields'].update(E=12),
                     lambda p:p['operations'][0]['row_operations'][0]['set_fields'].update(source_quote='rewrite'),
                     lambda p:p['operations'][0]['row_operations'][0]['set_fields'].update(review_status='PASS'),
                     lambda p:p['operations'][0]['row_operations'][0]['set_fields'].pop('canonical_mapping_status'),
                     lambda p:p['operations'][0].update(material_id='M2')]
        for mutate in mutations:
            self.proposal = copy.deepcopy(original)
            mutate(self.proposal)
            self.bind()
            with self.subTest(proposal=self.proposal), self.assertRaises(ValueError):
                native.prepare(self.site, self.proposal_path, **self.kwargs)

    def test_unapproved_wrong_approval_sha_and_self_approval_rejected(self):
        with self.assertRaises(ValueError):
            native.apply(self.site, self.proposal_path, self.candidate, **dict(self.authorized, approval_path=None))
        with self.assertRaises(ValueError):
            native.apply(self.site, self.proposal_path, self.candidate, **dict(self.authorized, approval_sha256='0'*64))
        for changes in (dict(status='PENDING'), dict(reviewer='author'), dict(host_call_id='other-call'), dict(proposal_sha256='0'*64)):
            self.bind()
            approval = native.load(self.approval_path)
            approval.update(changes)
            self.approval_path.write_bytes(native.dump(approval))
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                native.apply(self.site, self.proposal_path, self.candidate, **dict(self.authorized, approval_sha256=native.sha(self.approval_path)))
        self.assertFalse(self.candidate.exists())

    def test_receipt_host_match_cannot_mask_wrong_proposal_parent_decision_or_reviewer(self):
        for changes in (dict(proposal_sha256='0'*64), dict(parent_manifest_sha256='0'*64), dict(decision='HOLD'), dict(reviewer='other-agent')):
            self.bind()
            receipt = native.load(self.root / 'review.json')
            receipt.update(changes)
            (self.root / 'review.json').write_bytes(native.dump(receipt))
            approval = native.load(self.approval_path)
            approval['review_receipt_sha256'] = native.sha(self.root / 'review.json')
            self.approval_path.write_bytes(native.dump(approval))
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                native.apply(self.site, self.proposal_path, self.candidate, **dict(self.authorized, approval_sha256=native.sha(self.approval_path)))

    def test_tampered_numeric_child_even_with_rehashed_manifest_rejected(self):
        native.apply(self.site, self.proposal_path, self.candidate, **self.authorized)
        name = 'coverage-details/000.json.gz'
        values = json.loads(gzip.decompress((self.candidate / name).read_bytes()))
        values['values']['rho'] = 999
        (self.candidate / name).write_bytes(gzip.compress(native.canonical(values), mtime=0))
        manifest = native.load(self.candidate / 'MANIFEST.json')
        manifest['files'][name] = native.sha(self.candidate / name)
        (self.candidate / 'MANIFEST.json').write_bytes(native.dump(manifest))
        with self.assertRaisesRegex(ValueError, 'exact approved transformation'):
            native.verify(self.candidate, self.site, self.proposal_path, **self.authorized)
        with self.assertRaises(ValueError):
            native.apply(self.site, self.proposal_path, self.candidate, **self.authorized)

    def test_complete_snapshot_extra_mirror_and_wrong_frozen_bytes_rejected(self):
        self.put('objects/0001.json.gz', gzip.compress(native.canonical([dict(self.obj, id='O2')]), mtime=0))
        self.repin()
        self.bind()
        with self.assertRaisesRegex(ValueError, 'complete native snapshot'):
            native.prepare(self.site, self.proposal_path, **self.kwargs)
        (self.site / 'objects/0001.json.gz').unlink()
        self.repin()
        (self.root / 'private-inputs/objects/0000.json.gz').write_bytes(gzip.compress(b'[]', mtime=0))
        self.bind()
        with self.assertRaisesRegex(ValueError, 'Frozen input SHA'):
            native.prepare(self.site, self.proposal_path, **self.kwargs)

    def test_different_transaction_existing_target_and_symlink_rejected(self):
        self.candidate.mkdir()
        (self.candidate / 'unrelated.txt').write_text('keep')
        with self.assertRaises((ValueError, FileNotFoundError)):
            native.apply(self.site, self.proposal_path, self.candidate, **self.authorized)
        self.assertEqual((self.candidate / 'unrelated.txt').read_text(), 'keep')
        alias = self.root / 'alias'
        alias.symlink_to(self.candidate, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'Unsafe candidate'):
            native.apply(self.site, self.proposal_path, alias, **self.authorized)

    def test_partial_write_is_cleaned_without_publishing(self):
        with patch.object(native, 'verify', side_effect=ValueError('synthetic candidate gate rejection')):
            with self.assertRaises(ValueError):
                native.apply(self.site, self.proposal_path, self.candidate, **self.authorized)
        self.assertFalse(self.candidate.exists())
        self.assertFalse(list(self.root.glob('.child-*')))


if __name__ == '__main__':
    unittest.main()
