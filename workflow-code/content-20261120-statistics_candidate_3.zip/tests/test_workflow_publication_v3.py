"""Publication boundaries: immutable source, exact pins and no implicit approval."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / 'rsi_harness/workflow_publication_v3.py'
spec = importlib.util.spec_from_file_location('publication', MODULE)
pub = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pub)


class PublicationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='物性工作流-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.site = self.root / 'approved'
        self.site.mkdir()
        snapshot = dict(id='REVIEWED-1', kind='REVIEWED_RESEARCH_SNAPSHOT', completion_flags={'global_geometry_deduplicated': False})
        for name, value in [('snapshot.json', snapshot), ('research.json', {'meta': {'releaseId': snapshot['id']}}), ('coverage.json', {'releaseId': snapshot['id']}), ('INPUT_PINS.json', {'five_core_inputs': 'unchanged'}), ('workflow-data.json', {'version': 'old'})]:
            pub.write_json(self.site / name, value)
        (self.site / 'bootstrap.js').write_text("const version='REVIEWED-1';fetch('snapshot.json');")
        (self.site / 'snapshot.js').write_text(json.dumps(pub.PAGES))
        for page in (*pub.PAGES, 'index.html'):
            (self.site / page).write_text('<script src="bootstrap.js?v=1"></script><script src="snapshot.js?v=1"></script>')
        self.repin()

    def repin(self):
        pub.write_json(self.site / 'MANIFEST.json', dict(snapshot_id='REVIEWED-1', publication_type='REVIEWED_RESEARCH_SNAPSHOT', files={p.name: pub.sha(p) for p in self.site.iterdir() if p.name != 'MANIFEST.json'}))

    def test_build_retains_snapshot_source_and_versioned_config(self):
        before = pub.sha(self.site / 'MANIFEST.json')
        config = self.root / 'config.json'
        pub.write_json(config, {'version': '3', 'steps': []})
        candidate = self.root / 'candidate'
        result = pub.build_site(self.site, candidate, config)
        self.assertEqual(result['status'], 'PASS_SITE_SNAPSHOT_STRUCTURE')
        self.assertEqual(pub.sha(self.site / 'MANIFEST.json'), before)
        self.assertEqual((candidate / 'snapshot.json').read_bytes(), (self.site / 'snapshot.json').read_bytes())
        self.assertEqual((candidate / 'INPUT_PINS.json').read_bytes(), (self.site / 'INPUT_PINS.json').read_bytes())
        self.assertTrue((candidate / ('workflow-config/' + pub.sha(config) + '.json')).is_file())
        self.assertEqual(result['original_full_release_gates'], 'NOT_RUN_RESEARCH_SNAPSHOT')
        with self.assertRaisesRegex(ValueError, 'already exists'):
            pub.build_site(self.site, candidate)

    def test_manifest_tamper_blocks_before_target_creation(self):
        (self.site / 'coverage.json').write_text('{}')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            pub.build_site(self.site, self.root / 'candidate')
        self.assertFalse((self.root / 'candidate').exists())

    def test_content_override_preserves_every_scientific_resource(self):
        helper = self.root / 'helper.js'
        helper.write_text('window.PresentationFields = {};')
        page = self.root / 'page.html'
        page.write_text('<script src="bootstrap.js"></script><script src="presentation-fields.js"></script><script src="snapshot.js"></script>')
        candidate = self.root / 'candidate'
        pub.build_site(self.site, candidate, presentation_overrides={
            'presentation-fields.js': helper, 'scaling.html': page,
        })
        self.assertEqual(pub.sha(candidate / 'snapshot.json'), pub.sha(self.site / 'snapshot.json'))
        self.assertEqual(pub.sha(candidate / 'research.json'), pub.sha(self.site / 'research.json'))
        self.assertEqual(pub.sha(candidate / 'coverage.json'), pub.sha(self.site / 'coverage.json'))
        self.assertEqual(pub.sha(candidate / 'presentation-fields.js'), pub.sha(helper))

    def test_data_binding_style_and_arbitrary_script_overrides_rejected(self):
        replacement = self.root / 'replacement'
        replacement.write_text('{}')
        for i, name in enumerate(('snapshot.json', 'research.json', 'coverage.json',
                                  'objects/0000.json.gz', 'bootstrap.js', 'snapshot.css',
                                  'arbitrary.js', '../snapshot.js')):
            candidate = self.root / ('candidate-' + str(i))
            with self.assertRaisesRegex(ValueError, 'allowlisted presentation'):
                pub.build_site(self.site, candidate, presentation_overrides={name: replacement})
            self.assertFalse(candidate.exists())

    def test_statistics_stylesheet_is_pinned_without_replacing_shared_styles(self):
        stylesheet = self.root / 'statistics-panel.css'
        stylesheet.write_text('.snapshot-status .statistics-grid { display: grid; }')
        candidate = self.root / 'candidate'
        pub.build_site(self.site, candidate, presentation_overrides={'statistics-panel.css': stylesheet})
        self.assertEqual(pub.sha(candidate / 'statistics-panel.css'), pub.sha(stylesheet))
        self.assertEqual(pub.sha(candidate / 'snapshot.json'), pub.sha(self.site / 'snapshot.json'))
        manifest = pub.read_json(candidate / 'MANIFEST.json')
        self.assertEqual(set(manifest['workflow_presentation_overrides']), {'statistics-panel.css'})

    def test_rehashed_data_change_in_presentation_candidate_still_rejected(self):
        candidate = self.root / 'candidate'
        pub.build_site(self.site, candidate)
        pub.write_json(candidate / 'coverage.json', {'releaseId': 'REVIEWED-1', 'invented': 100})
        manifest = pub.read_json(candidate / 'MANIFEST.json')
        manifest['files']['coverage.json'] = pub.sha(candidate / 'coverage.json')
        manifest['workflow_presentation_overrides'] = {'coverage.json': pub.sha(candidate / 'coverage.json')}
        pub.write_json(candidate / 'MANIFEST.json', manifest)
        with self.assertRaisesRegex(ValueError, 'Invalid presentation override'):
            pub.validate_site(candidate)

    def test_native_digest_without_exact_data_contract_is_rejected(self):
        manifest = pub.read_json(self.site / 'MANIFEST.json')
        manifest['native_correction_digest'] = 'a' * 64
        pub.write_json(self.site / 'MANIFEST.json', manifest)
        with self.assertRaisesRegex(ValueError, 'Missing or unknown native correction contract'):
            pub.validate_site(self.site)

    def test_native_contract_cannot_be_relabelled_as_presentation_only(self):
        import hashlib
        manifest = pub.read_json(self.site / 'MANIFEST.json')
        contract = {'schema': 'rsi-native-data-correction-v1'}
        manifest['data_correction_contract'] = contract
        manifest['native_correction_digest'] = hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        manifest['workflow_parent'] = {'source_site': str(self.site), 'manifest_sha256': 'a' * 64}
        pub.write_json(self.site / 'MANIFEST.json', manifest)
        with self.assertRaisesRegex(ValueError, 'Data correction cannot use a presentation-only parent'):
            pub.validate_site(self.site)

    def test_native_correction_cannot_use_a_presentation_only_review(self):
        self.assert_ui_only_publication_blocked('a' * 64, 'Native data correction needs independent data')

    def test_rootless_snapshot_cannot_use_a_presentation_only_review(self):
        self.assert_ui_only_publication_blocked(None, 'Scientific website publication needs independent data')

    def assert_ui_only_publication_blocked(self, native_digest, error):
        manifest = pub.read_json(self.site / 'MANIFEST.json')
        if native_digest:
            manifest['native_correction_digest'] = native_digest
        pub.write_json(self.site / 'MANIFEST.json', manifest)
        manifest_sha = pub.sha(self.site / 'MANIFEST.json')
        review_path = self.root / 'review.json'
        pub.write_json(review_path, {'status': 'PASS', 'actionable_findings': 0,
            'reviewed_export_manifest_sha256': manifest_sha, 'reviewer': 'independent',
            'author': 'collector', 'scope': 'PRESENTATION_ONLY'})
        approval_path = self.root / 'approval.json'
        pub.write_json(approval_path, {'schema': 'rsi-reviewed-research-snapshot-publication-approval-v1',
            'decision': 'APPROVE_EXACT_REVIEWED_EXPORT', 'working_research_snapshot_publication_authorized': True,
            'export_root': str(self.site), 'export_manifest_path': str(self.site / 'MANIFEST.json'),
            'export_manifest_sha256': manifest_sha, 'snapshot_id': 'REVIEWED-1',
            'expected_remote_commit': 'b' * 40, 'manifest_upload_name': 'MANIFEST.json',
            'independent_review_manifest_path': str(review_path),
            'independent_review_manifest_sha256': pub.sha(review_path)})
        validation = {'publication_type': 'REVIEWED_RESEARCH_SNAPSHOT', 'manifest_sha256': manifest_sha,
                      'snapshot_id': 'REVIEWED-1'}
        with patch.object(pub, 'validate_site', return_value=validation):
            with self.assertRaisesRegex(ValueError, error):
                pub.prepare_publication(self.site, approval_path, pub.sha(approval_path), None, 'b' * 40)

    def test_presentation_wrapper_cannot_hide_an_invalid_native_parent(self):
        import shutil
        manifest = pub.read_json(self.site / 'MANIFEST.json')
        manifest['native_correction_digest'] = 'a' * 64
        pub.write_json(self.site / 'MANIFEST.json', manifest)
        wrapped = self.root / 'wrapped'
        shutil.copytree(self.site, wrapped)
        manifest.pop('native_correction_digest')
        manifest['workflow_parent'] = {'source_site': str(self.site), 'manifest_sha256': pub.sha(self.site / 'MANIFEST.json')}
        pub.write_json(wrapped / 'MANIFEST.json', manifest)
        with self.assertRaisesRegex(ValueError, 'Missing or unknown native correction contract'):
            pub.validate_site(wrapped)

    def test_native_lineage_is_preserved_by_legitimate_presentation_builds(self):
        import hashlib
        import shutil
        native = self.root / 'native'
        shutil.copytree(self.site, native)
        manifest = pub.read_json(native / 'MANIFEST.json')
        contract = {'schema': 'rsi-native-data-correction-v1', 'parent': {
            'source_site': str(self.site), 'manifest_sha256': pub.sha(self.site / 'MANIFEST.json')}}
        digest = hashlib.sha256(json.dumps(contract, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        manifest.update(data_correction_contract=contract, native_correction_digest=digest)
        pub.write_json(native / 'MANIFEST.json', manifest)
        wrapped = self.root / 'wrapped'
        with patch('rsi_harness.workflow_native_corrections_v3.verify', return_value={'status': 'PASS_NATIVE_CORRECTION'}):
            validation = pub.build_site(native, wrapped)
            self.assertEqual(validation['effective_native_correction_digest'], digest)
            child = pub.read_json(wrapped / 'MANIFEST.json')
            self.assertNotIn('data_correction_contract', child)
            self.assertEqual(child['inherited_native_correction']['native_correction_digest'], digest)
            child.pop('inherited_native_correction')
            pub.write_json(wrapped / 'MANIFEST.json', child)
            with self.assertRaisesRegex(ValueError, 'dropped or weakened native data lineage'):
                pub.validate_site(wrapped)

    def test_path_escape_and_symlinks_rejected(self):
        manifest = pub.read_json(self.site / 'MANIFEST.json')
        outside = self.root / 'outside.json'
        outside.write_text('{}')
        for name in ('../outside.json', '/outside.json', 'a\\b'):
            manifest['files'][name] = pub.sha(outside)
            pub.write_json(self.site / 'MANIFEST.json', manifest)
            with self.assertRaises(ValueError):
                pub.verify_manifest(self.site)
            del manifest['files'][name]
        (self.site / 'linked.json').symlink_to(outside)
        manifest['files']['linked.json'] = pub.sha(outside)
        pub.write_json(self.site / 'MANIFEST.json', manifest)
        with self.assertRaises(ValueError):
            pub.verify_manifest(self.site)

    def test_mixed_snapshot_ids_rejected_even_with_valid_hashes(self):
        pub.write_json(self.site / 'coverage.json', {'releaseId': 'OTHER'})
        self.repin()
        with self.assertRaisesRegex(ValueError, 'Snapshot ID mismatch: coverage'):
            pub.validate_site(self.site)

    def test_unpinned_resource_and_missing_four_page_navigation_rejected(self):
        (self.site / 'workflow.html').write_text('<script src="../escape.js"></script>')
        self.repin()
        with self.assertRaisesRegex(ValueError, 'unpinned resource'):
            pub.validate_site(self.site)
        (self.site / 'workflow.html').write_text('<script src="bootstrap.js"></script><script src="snapshot.js"></script>')
        (self.site / 'snapshot.js').write_text('scaling.html research.html references.html')
        self.repin()
        with self.assertRaisesRegex(ValueError, 'four-page navigation'):
            pub.validate_site(self.site)

    def test_no_approval_never_invokes_publisher(self):
        with patch.object(pub.subprocess, 'run') as runner:
            with self.assertRaisesRegex(ValueError, 'approval required'):
                pub.publish_site(self.site, None, None, None, None, execute=True)
            runner.assert_not_called()

    def test_full_release_does_not_bypass_original_gates(self):
        snapshot = pub.read_json(self.site / 'snapshot.json')
        snapshot['kind'] = 'FULL_RELEASE'
        pub.write_json(self.site / 'snapshot.json', snapshot)
        self.repin()
        manifest = pub.read_json(self.site / 'MANIFEST.json')
        manifest['publication_type'] = 'FULL_RELEASE'
        pub.write_json(self.site / 'MANIFEST.json', manifest)
        with self.assertRaisesRegex(ValueError, 'original validators'):
            pub.validate_site(self.site)
        with patch.object(pub, 'run_full_release_gates', return_value=[{'passed': False}]) as gates:
            with self.assertRaisesRegex(ValueError, 'gates blocked'):
                pub.validate_site(self.site, full_release_root=self.root, report_dir=self.root / 'reports')
            gates.assert_called_once()

    def test_browser_report_cannot_mutate_site(self):
        with self.assertRaisesRegex(ValueError, 'outside immutable'):
            pub.browser_check(self.site, self.site / 'screenshots')

    def test_snapshot_or_completion_change_from_parent_rejected(self):
        candidate = self.root / 'candidate'
        pub.build_site(self.site, candidate)
        snapshot = pub.read_json(candidate / 'snapshot.json')
        snapshot['completion_flags']['global_geometry_deduplicated'] = True
        pub.write_json(candidate / 'snapshot.json', snapshot)
        manifest = pub.read_json(candidate / 'MANIFEST.json')
        manifest['files']['snapshot.json'] = pub.sha(candidate / 'snapshot.json')
        pub.write_json(candidate / 'MANIFEST.json', manifest)
        with self.assertRaisesRegex(ValueError, 'changed data snapshot/completion'):
            pub.validate_site(candidate)


if __name__ == '__main__':
    unittest.main()
